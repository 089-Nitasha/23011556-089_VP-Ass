﻿namespace VP_ASS_2_089.Program2_StudentSystem
{
    public class Student
    {
        public string? Name { get; set; }
        public int Age { get; set; }
        public string? Class { get; set; }
    }

}
