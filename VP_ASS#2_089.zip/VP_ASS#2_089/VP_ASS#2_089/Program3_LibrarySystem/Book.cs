﻿namespace VP_ASS_2_089.Program3_LibrarySystem
{
    public class Book
    {
        public string? Title { get; set; }
        public string? Author { get; set; }
        public bool IsAvailable { get; set; } = true;
    }
}
